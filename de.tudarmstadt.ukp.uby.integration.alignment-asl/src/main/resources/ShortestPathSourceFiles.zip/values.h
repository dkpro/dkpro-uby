#define MAXLONG                 2147483648
#define atoll (long long) atof
